Dotpay Chrome plugin v 1.0.0 - beta
=====

## Instalacja testowa:

* W prawym górnym rogu w przeglądarce chrome klikamy w ikone do ustawien, a nastepnie wybieramy z listy settings.
* Z lewego menu wybieramy extensions i zaznaczmy na gorze 'developer mode'
* Nastepnie kilikamy 'load unpacked extensions' i wskazujemy glowny folder
* Wtyczka aktywuje sie na stronach obu bankow oraz na stonie dotpay-a zwiazanej z tymi bankami.
